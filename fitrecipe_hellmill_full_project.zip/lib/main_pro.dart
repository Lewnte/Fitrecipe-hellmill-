import 'package:flutter/material.dart';
import 'main_common.dart';

void main() {
  runApp(const MyApp(env: 'pro'));
}
